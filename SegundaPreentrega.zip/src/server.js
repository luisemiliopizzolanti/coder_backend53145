import express from 'express';
import productsRouter from './routes/products.router.js'
import cartsRouter from './routes/carts.router.js'
import viewsRouter from './routes/views.router.js'
import handlebars from "express-handlebars";
import socketManager from './managers/SocketManager.js';
import { Server } from "socket.io";
import { __dirname } from "./utils.js";
import { connectDB } from './config/index.js';
import { checkDbConnection } from './middlewere/index.js';

const app = express();
app.use(express.json());
app.use(express.urlencoded({extended:true}));

app.use(express.static(__dirname + "/public"));
app.engine("handlebars", handlebars.engine(
        {
            runtimeOptions: {
                allowProtoPropertiesByDefault: true,
                allowProtoMethodsByDefault: true
            }   
        }
    )
);
app.set("view engine", "handlebars");
app.set("views", __dirname + "/views");
//Middleware para verificar si hay conexion con la DB, lo dejo como global para que verifique en aca endpoint
app.use(checkDbConnection)


//Defino las rutas
app.use('/products',productsRouter)
app.use('/carts',cartsRouter)
app.use('/views',viewsRouter)


app.get('/',(req, res)=>{
    res.render('inicio')
})

try {
    console.log("conectando DB")
    await connectDB();
 } catch (error) {
    console.log(error)
    console.error("Error al conectar DB")
    console.log("Servidor terminado")
    process.exit(1)
}

const httpServer = app.listen(8080, ()=>{
    console.log('Server ok on port 8080');
})


const socketServer = new Server(httpServer)
socketManager(socketServer)

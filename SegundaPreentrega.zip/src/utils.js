import { dirname } from "path";
import { fileURLToPath } from "url";

export const __dirname = dirname(fileURLToPath(import.meta.url));
export const validateProduct = (productParam)=>{

    const {title, description,price,thumbnail,code,stock,category,status} = productParam
        if(!title){
            throw {error:"Falta titulo"}
        } 
        if(!description){
            throw {error:"Falta descripcion"}
        } 
        if(!price){
            throw {error:"Falta precio"}
        } 
        if(!Number.isInteger(price)){
           throw {error:"precio no es un numero"}
        }
        if(!thumbnail){
            throw {error:"Falta imagenes"}
        }
        if(!code){
            throw {error:"Falta codigo"}
        }
        if(!Number.isInteger(code)){
            throw {error:"El codigo no es un numero"}
        }
        if(!stock){
            throw {error:"Falta stock"}
        }
        if(!Number.isInteger(stock)){
            throw {error:"Stock no es un numero"}
        } 
        if(!category){
            throw {error:"Falta categoria"}
        }
         if(typeof status !== "boolean"){
            throw {error:"Falta status"}
        }
}

export const getBaseURL = (req)=>{

    const protocol = req.protocol;
    const host = req.get('host');
    const fullUrl = `${protocol}://${host}`;
    return fullUrl
}
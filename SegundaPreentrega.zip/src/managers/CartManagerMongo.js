import { cartsModel } from "../models/carts.model.js";
import ProductManagerMongo from "./ProductManagerMongo.js";


export default class CartManagerMongo{
    
    constructor(){
        this.carts = cartsModel
    }


    async addCart(products){
        const productManager = new ProductManagerMongo()
        const productsToadd = []
        for(const p of products){
            let product={}
            try{
                product = await productManager.getProductBy({_id:p.id})
            }catch(error){
                throw({
                    status:"error",
                    msg:"error consulta producto BD, no se creo el carrito"
                })
            }
            try{
                if (product.length===0){
                    console.log("largo 0")
                    throw({
                        status:"error",
                        msg:"producto no encontrado, no se ha creado el carrito",
                        idProd:p.id
                    })
                    return
                }
            }catch(error){
                throw(error)
            }

            productsToadd.push({
                product:p.id,
                quantity:p.quantity
            }) 
        }
        try{
            const cart = await this.carts.create({products:productsToadd})
            return cart
        }catch(error){
            throw({
                status:"error",
                msg:"error al crear el carrito"
            })
        }
}

    async getCartsBy(filter){
        let cartByFilter={}
        try{
           
         cartByFilter=await this.carts.find(filter)

        }catch(error){
            throw new Error({
                status:"error",
                msg:"error consulta DB"
            })
        }
        if (cartByFilter.length===0){
            throw new Error({
                status:"ok",
                msg:"carrito no encontrado"
            })
        }
        return cartByFilter
    }

    async addProductToCart(cartID,productID,quantity){
            const productManager = new ProductManagerMongo()
            let product={}
            try{
                product= await productManager.getProductBy({
                    _id:productID
                })
            }catch (error){
                
                throw new Error({
                    status:"error",
                    msg:"error bd agregarProductToCart"
                })
            }
            
            if (!product) {
                throw new Error({
                    status:"error",
                    msg:"el producto no existe"
                })
            }
            
            const cart = await cartsModel.findById(cartID)
            if (!cart) {
                throw new Error({
                    status:"error",
                    msg:"el carrito no existe"
                })
            }
            //console.log(cart)
            try{
                //console.log(quantity)
                const existingProductIndex = cart.products.findIndex( (p) => p.product.toString() === productID.toString());
                if (existingProductIndex > -1) {
                    console.log(cart.products)
                    // Si el producto ya está en el carrito, actualizar la cantidad
                    cart.products[existingProductIndex].quantity += quantity;
                    
                } else {
                    // Si el producto no está en el carrito, agregarlo
                    cart.products.push({ product: productID, quantity });
                }
                
                // Guardar el carrito actualizado
                return await cart.save();
                 
            }catch(error){
                console.log(error)
                throw new Error({
                    
                    status:"error",
                    msg:"error al actualizar carrito"
                })
            }
            
    }

    async deleteCart(idCart){
        try{
            const cart = await this.carts.findByIdAndDelete(idCart);
            if (!cart) {
                throw new Error({
                    status:"error",
                    msg:"carrito no encontrado"
                })
            }
        }catch(error){
            throw new Error({
                status:"error",
                msg:"error al borrar carrito"

            })
        }
        return cart
    }

    async deleteProductFromCart(cartID, productID){
            const productManager = new ProductManagerMongo()
            let product = {}
            try{
                 product= await productManager.getProductBy({
                    _id:productID
                })
            }catch(error){
                throw(error)
            }
            
            if (!product) {
                throw new Error({
                    status:"error",
                    msg:"el producto no existe"
                })
            }
            const cart={}
            try{
                cart = await cartsModel.findById(cartID)
            }catch(error){
                throw new Error({
                    status:"error",
                    msg:"error DB, id cart invalido"
                })
            }
             
            if (!cart) {
                throw new Error({
                    status:"error",
                    msg:"el carrito no existe"
                })
            }
            
            const existingProductIndex = cart.products.findIndex( (p) => p.product.toString() === productID.toString());
            if (existingProductIndex > -1) {
                // Si el producto esta en el carrito lo borro
                cart.products.splice(existingProductIndex, 1);
            }else{
                throw new Error({
                    status:"error",
                    msg:"el producto no esta en el carrito"
                })
            }
            
            try{      
                          
                // Guardar el carrito actualizado
                return await cart.save();
                 
            }catch(error){
                throw new Error({
                    status:"error",
                    msg:"error al actualizar carrito"
                })
            }
    }

    async deleteAllProductsFromCart(cartID){
        let cart={}
        try{
            cart = await cartsModel.findById(cartID)
        }catch(error){
            throw new Error({
                status:"error",
                msg:"error DB borrar todos los productos carrito"
            })
        }

        if (!cart) {
            throw new Error({
                status:"error",
                msg:"el carrito no existe"
            })
        }
        
        try{       
            cart.products.splice(0,cart.products.length)   
            // Guardar el carrito sin productos
            await cart.save();
            return {
                status:"ok",
                msg:"productos eliminados"
            }

        }catch(error){
            throw new Error({
                status:"error",
                msg:"error al actualizar carrito"
            })
        }
}




}

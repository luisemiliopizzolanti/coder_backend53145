import { productssModel } from "../models/products.model.js";
import { validateProduct } from "../utils.js";

class ProductManagerMongo{
    
    constructor(){
        this.products = productssModel
    }

    async addProduct(productParam){
        //Busco por si hay alguno con el codigo repetido
        const product = await this.getProductBy({ code: productParam.code})
        if (product.length!=0){
            throw({error: "codigo repetido"})
        }
        try{
           return await this.products.create(productParam)
        }catch(error){
            throw({error: "Error al crear documento"})
        }
        
    }

    async getProductBy(filter={}, limit = 10){
        
        let products = {}
        try{
            products = await this.products.find(filter).limit(limit)
        }catch(error){
            throw({
                status:"error",
                msg:"error consulta DB, id producto invalida"
            })
        }
        if(products.length===0){
            throw({
                status:"error",
                msg:"producto no encontrado"
            })
        }
        return products
       
    }

    async getProductPaginateBy(filter={}, limit = 3, numPage=1, sort={}){
        try{

            if(sort==="asc") sort = { price: 1 }
            if(sort==="desc") sort = { price: -1 }
            //filter es el filtro que paso por paramentro, en caso de no pasar nada es vacio
            //el segundo parametro son las opciones del paginado
            //limit, la cantidad de registros por pagina
            //page, la pagina que quiero mostrar
            //sort, es como quiero ordenar
            return await this.products.paginate(filter, {limit, page: numPage, sort: sort, lean: true })
        }catch(error){
            throw({
                status:"error consulta DB"
            })
        }
       
    }

    async updateProduct(productToUpdate){
        try{
            const product = await this.products.findByIdAndUpdate(id, updates, { new: true });
            if (!product) {
                throw({
                    status:"error",
                    msg:"prodcuto no encontrado"
                })
            }
        }catch(error){
            throw({
                status:"error",
                msg:"error al actualizad DB"

            })
        }
        return product
    }

    async deleteProduct(productToUpdate){
        try{
            const product = await this.products.findByIdAndDelete(productToUpdate);
            if (!product) {
                throw({
                    status:"error",
                    msg:"prodcuto no encontrado"
                })
            }
        }catch(error){
            throw({
                status:"error",
                msg:"error al actualizad DB"

            })
        }
        return product
    }

}

export default ProductManagerMongo
import { Schema,model } from "mongoose";

const cartSchema = new Schema({
    products: {
        type: [{
            product: {
                type: Schema.Types.ObjectId,
                ref: 'products'
            },
            quantity: Number
        }]
    }
})

//Al devolver un carrito devueleve un conjunto de productos que los trae de la coleccion products
cartSchema.pre('find', function() {
    this.populate('products.product')
})

export const cartsModel = model('carts', cartSchema)
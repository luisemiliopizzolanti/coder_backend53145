import { Router} from 'express';
import ProductManager from '../managers/ProductManagerFS.js';
import CartManagerMongo from '../managers/CartManagerMongo.js';


const router = Router();
const productManager = new ProductManager("./products.json")
//const cartManager = new CartManager("./carts.json")
const cartManager = new CartManagerMongo()
/*
router.get('/:cid',async(req,res)=>{
    try{
        
        const {cid} = req.params
        const cartWithProducts = await cartManager.getCartByIDWithProducts(parseInt(cid))
        res.status(200).send(JSON.stringify(cartWithProducts))
    }catch(error){
        console.log(error)
    }   
})*/

router.get('/',async(req,res)=>{
    const productos =[
        {
            id:"665005d431ab6ee60bca20da",
            quantity:2
        },
        {
            id:"6651310e0dc825e9da1abbd1",
            quantity:5
        }
    ]
    try{
        //const cart =await cartManager.addCart(productos)
        //console.log(cart)
        //const cartAdded = await cartManager.addProductToCart("665a230fbb354e68fc3f0332","6651310e0dc825e9da1abbd1",200)
        //console.log(cartAdded)
        
        let cart = await cartManager.deleteAllProductsFromCart({_id:"665a230fbb354e68fc3f0332"})
        cart = await cartManager.getCartsBy({_id:"665a230fbb354e68fc3f0332"})
        //const prodct = await cartManager.deleteProductFromCart("665a230fbb354e68fc3f0332","6651310e0dc825e9da1abbd1")
        

        res.send(cart)
    }catch(error){
        console.log(error)
        res.send(error)
    }
    

})


//Crea un carrito
router.post('/',async(req,res)=>{
    try{
        const productos = req.body;
        const  response= await cartManager.createCart(productos);
        console.log(productos)
        res.status(200).send(response)
    }catch(error){
        console.log(error)
    } 
})


//Agrega un arrary de productos al carrito
router.post('/:cid',async(req,res)=>{
    try{
        const cartID = req.params.cid
        const productos = req.body;
        const  response= await cartManager.addProductToCart(cartID,productos);
        console.log(productos)
        res.status(200).send(response)
    }catch(error){
        console.log(error)
    } 
})

//Agrega un producto al carrito
router.put('/:cid/product/:pid',async(req,res)=>{
    try{
        const {cid,pid} = req.params
        const {quantity} = req.body
        const response = await cartManager.addProductToCart(cid,pid,quantity)
        res.send(response)
    }catch(error){
        res.send(error)
    }
})

//Borra un producto del carrito
router.delete('/:cid/product/:pid',async(req,res)=>{
    try{
        const {cid,pid} = req.params
        const response = await cartManager.deleteProductFromCart(cid,pid)
        res.status(200).send(response)
    }catch(error){
        res.status(200).send(error)
    }

})
//Borra todos los productos del carrito
router.delete('/:cid', async(req,res)=>{
    try{
        const {cid,pid} = req.params
        const response = await cartManager.deleteProductFromCart(cid,pid)
        res.status(200).send(response)
    }catch(error){
        res.status(200).send(error)
    }
})


export default router
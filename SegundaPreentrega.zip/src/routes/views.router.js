import { Router } from 'express';
import ProductManagerMongo from "../managers/ProductManagerMongo.js";
import CartManagerMongo from '../managers/CartManagerMongo.js';
const router = Router();
const prodctManagerMongo = new ProductManagerMongo();
const cartManagerMongo = new CartManagerMongo();

router.get("/",async(req,res)=>{    
    res.status(200).render("home")
})

router.get("/realTimeProducts",async(req,res)=>{
    res.status(200).render("realTimeProducts")
})


router.get("/products",async(req,res)=>{
try{
    let {page,cartID,prodID} = req.query
    if(!page) page = 1
    if(prodID){
        if(cartID) {
            const cart = await cartManagerMongo.addProductToCart(cartID,prodID,1)
            console.log(cart)
        }else{
            const newCart = await cartManagerMongo.addCart([{id:prodID,quantity:1}])
            cartID = newCart._id.toString()
        }

    }
    
    let data = await prodctManagerMongo.getProductPaginateBy({},4,page,"asc")
    data={
        ...data,
        "cartID":cartID

    }
    res.status(200).render("products",data)
    //console.log(data)
}catch(error){
    console.log(error)
}
})

router.get('/cart/:cid',async(req,res)=>{

    const {cid} = req.params
    try {
        const data = await cartManagerMongo.getCartsBy({_id:cid})
       // console.log(data[0])
        res.status(200).render("cart",data[0])
        //res.send(data[0])
    } catch (error) {
        console.log(error)
    }

})





export default router